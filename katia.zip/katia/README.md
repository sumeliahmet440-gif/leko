# Katia AI
Render'da Web Service olarak yayınla: Build `npm install`, Start `node server.js`, Environment: `GROQ_API_KEY`.
